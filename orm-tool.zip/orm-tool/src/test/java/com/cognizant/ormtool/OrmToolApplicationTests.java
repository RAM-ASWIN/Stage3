package com.cognizant.ormtool;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrmToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
